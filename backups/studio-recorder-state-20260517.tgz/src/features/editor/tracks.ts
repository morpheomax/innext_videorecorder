import type { EditorClip, EditorTrackDefinition, EditorTrackId } from './types';

export const EDITOR_TRACKS: EditorTrackDefinition[] = [
  { id: 'video-1', label: 'Video 1', kind: 'video' },
  { id: 'video-2', label: 'Video 2', kind: 'video' },
  { id: 'video-3', label: 'Video 3', kind: 'video' },
  { id: 'audio-1', label: 'Audio 1', kind: 'audio' },
  { id: 'audio-2', label: 'Audio 2', kind: 'audio' },
  { id: 'overlay-1', label: 'Overlay', kind: 'overlay' },
];

export function getTrackDefinition(trackId: EditorTrackId) {
  return EDITOR_TRACKS.find((track) => track.id === trackId) ?? EDITOR_TRACKS[0];
}

export function getTrackOrder(trackId: EditorTrackId) {
  return EDITOR_TRACKS.findIndex((track) => track.id === trackId);
}

export function getTrackEnd(clips: EditorClip[], trackId: EditorTrackId) {
  return clips
    .filter((clip) => clip.trackId === trackId)
    .reduce((max, clip) => Math.max(max, clip.startTime + (clip.trimEnd - clip.trimStart)), 0);
}

export function getDefaultTrackId(kind: EditorClip['kind']): EditorTrackId {
  if (kind === 'audio') {
    return 'audio-1';
  }

  if (kind === 'text') {
    return 'overlay-1';
  }

  return 'video-1';
}
