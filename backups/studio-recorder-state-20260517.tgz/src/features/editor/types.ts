export type EditorTrackId = 'video-1' | 'video-2' | 'video-3' | 'audio-1' | 'audio-2' | 'overlay-1';

export type EditorClipKind = 'video' | 'audio' | 'image' | 'text';

export interface EditorClip {
  id: string;
  name: string;
  kind: EditorClipKind;
  trackId: EditorTrackId;
  startTime: number;
  trimStart: number;
  trimEnd: number;
  duration: number;
  volume: number;
  muted: boolean;
  url?: string;
  blob?: Blob;
  text?: string;
  color?: string;
  background?: string;
}

export interface EditorAsset {
  blob: Blob;
  name: string;
}

export interface EditorTrackDefinition {
  id: EditorTrackId;
  label: string;
  kind: 'video' | 'audio' | 'overlay';
}
