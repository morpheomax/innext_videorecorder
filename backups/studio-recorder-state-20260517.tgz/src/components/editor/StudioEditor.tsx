import { useEffect, useMemo, useRef, useState } from 'react';
import { RecorderPipeline } from '../../core/recorder/recorder-pipeline';
import { studioStorage, type ProjectRecord } from '../../core/storage/studio-storage';
import { EDITOR_TRACKS, getDefaultTrackId, getTrackDefinition, getTrackEnd, getTrackOrder } from '../../features/editor/tracks';
import type { EditorAsset, EditorClip, EditorTrackId } from '../../features/editor/types';

interface StudioEditorProps {
  initialAsset: EditorAsset | null;
  sessionKey: number;
  onBackToStudio: () => void;
}

type DragMode =
  | { type: 'move'; clipId: string; startX: number; startTime: number }
  | { type: 'trim-start'; clipId: string; startX: number; startTrim: number; startTime: number }
  | { type: 'trim-end'; clipId: string; startX: number; startTrim: number };

const PREVIEW_WIDTH = 1280;
const PREVIEW_HEIGHT = 720;
const DEFAULT_ZOOM = 84;
const MIN_CLIP_DURATION = 0.25;

function formatSeconds(seconds: number) {
  const total = Math.max(0, seconds);
  const hrs = Math.floor(total / 3600)
    .toString()
    .padStart(2, '0');
  const mins = Math.floor((total % 3600) / 60)
    .toString()
    .padStart(2, '0');
  const secs = Math.floor(total % 60)
    .toString()
    .padStart(2, '0');
  return `${hrs}:${mins}:${secs}`;
}

function clipDuration(clip: EditorClip) {
  return Math.max(0, clip.trimEnd - clip.trimStart);
}

function clipEnd(clip: EditorClip) {
  return clip.startTime + clipDuration(clip);
}

function sortClips(a: EditorClip, b: EditorClip) {
  return a.startTime - b.startTime || a.name.localeCompare(b.name);
}

function isVisualClip(clip: EditorClip) {
  return clip.kind === 'video' || clip.kind === 'image' || clip.kind === 'text';
}

function isMediaClip(clip: EditorClip) {
  return clip.kind === 'video' || clip.kind === 'audio';
}

function createClipId() {
  return `clip-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
}

function drawContain(
  ctx: CanvasRenderingContext2D,
  element: HTMLVideoElement | HTMLImageElement,
  width: number,
  height: number,
) {
  const mediaWidth = 'videoWidth' in element ? element.videoWidth : element.naturalWidth;
  const mediaHeight = 'videoHeight' in element ? element.videoHeight : element.naturalHeight;
  if (!mediaWidth || !mediaHeight) {
    return;
  }

  const scale = Math.min(width / mediaWidth, height / mediaHeight);
  const drawWidth = mediaWidth * scale;
  const drawHeight = mediaHeight * scale;
  const x = (width - drawWidth) / 2;
  const y = (height - drawHeight) / 2;
  ctx.drawImage(element, x, y, drawWidth, drawHeight);
}

function drawCover(
  ctx: CanvasRenderingContext2D,
  element: HTMLVideoElement | HTMLImageElement,
  width: number,
  height: number,
) {
  const mediaWidth = 'videoWidth' in element ? element.videoWidth : element.naturalWidth;
  const mediaHeight = 'videoHeight' in element ? element.videoHeight : element.naturalHeight;
  if (!mediaWidth || !mediaHeight) {
    return;
  }

  const scale = Math.max(width / mediaWidth, height / mediaHeight);
  const drawWidth = mediaWidth * scale;
  const drawHeight = mediaHeight * scale;
  const x = (width - drawWidth) / 2;
  const y = (height - drawHeight) / 2;
  ctx.drawImage(element, x, y, drawWidth, drawHeight);
}

export default function StudioEditor({ initialAsset, sessionKey, onBackToStudio }: StudioEditorProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioDestinationRef = useRef<MediaStreamAudioDestinationNode | null>(null);
  const mediaNodesRef = useRef<
    Map<
      string,
      {
        element: HTMLVideoElement | HTMLAudioElement;
        source: MediaElementAudioSourceNode;
        gain: GainNode;
      }
    >
  >(new Map());
  const imageNodesRef = useRef<Map<string, HTMLImageElement>>(new Map());
  const rafRef = useRef<number>(0);
  const dragRef = useRef<DragMode | null>(null);
  const lastTickRef = useRef<number | null>(null);
  const importedSessionRef = useRef<number | null>(null);
  const exportRecorderRef = useRef<RecorderPipeline | null>(null);
  const historyRef = useRef<EditorClip[][]>([]);
  const skipHistoryRef = useRef(false);

  const [clips, setClips] = useState<EditorClip[]>([]);
  const [selectedClipId, setSelectedClipId] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [zoom, setZoom] = useState(DEFAULT_ZOOM);
  const [textDraft, setTextDraft] = useState('Nuevo texto');
  const [exporting, setExporting] = useState(false);
  const [exportUrl, setExportUrl] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [projects, setProjects] = useState<ProjectRecord[]>([]);
  const [savingProject, setSavingProject] = useState(false);

  const totalDuration = useMemo(
    () => clips.reduce((max, clip) => Math.max(max, clipEnd(clip)), 0),
    [clips],
  );

  const selectedClip = useMemo(
    () => clips.find((clip) => clip.id === selectedClipId) ?? null,
    [clips, selectedClipId],
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) {
      return;
    }

    const ctx = new AudioContext();
    const destination = ctx.createMediaStreamDestination();
    audioContextRef.current = ctx;
    audioDestinationRef.current = destination;

    canvas.width = PREVIEW_WIDTH;
    canvas.height = PREVIEW_HEIGHT;

    return () => {
      if (exportUrl) {
        URL.revokeObjectURL(exportUrl);
      }

      cancelAnimationFrame(rafRef.current);
      mediaNodesRef.current.forEach((node) => {
        node.element.pause();
        node.element.src = '';
        node.gain.disconnect();
        node.source.disconnect();
      });
      imageNodesRef.current.clear();
      mediaNodesRef.current.clear();
      void ctx.close();
    };
  }, []);

  useEffect(() => {
    void refreshProjects();
  }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const isEditable =
        target instanceof HTMLInputElement ||
        target instanceof HTMLTextAreaElement ||
        target instanceof HTMLSelectElement ||
        target?.isContentEditable;

      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'z') {
        event.preventDefault();
        undoLastChange();
        return;
      }

      if (isEditable) {
        return;
      }

      if ((event.key === 'Delete' || event.key === 'Backspace') && selectedClipId) {
        event.preventDefault();
        deleteClip(selectedClipId);
        return;
      }

      if (event.key.toLowerCase() === 'c' && selectedClipId) {
        event.preventDefault();
        splitClip(selectedClipId);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [selectedClipId, currentTime, clips]);

  useEffect(() => {
    if (!initialAsset || importedSessionRef.current === sessionKey) {
      return;
    }

    importedSessionRef.current = sessionKey;
    void importBlobAsClip(initialAsset.blob, initialAsset.name, 'video', true);
  }, [initialAsset, sessionKey]);

  useEffect(() => {
    const loop = (timestamp: number) => {
      const last = lastTickRef.current;
      const delta = last ? (timestamp - last) / 1000 : 0;
      lastTickRef.current = timestamp;

      setCurrentTime((time) => {
        if (!isPlaying) {
          return time;
        }

        const next = time + delta;
        if (next >= totalDuration) {
          handlePlaybackEnd();
          return totalDuration;
        }

        return next;
      });

      renderPreview();
      syncMediaPlayback();
      rafRef.current = requestAnimationFrame(loop);
    };

    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  });

  useEffect(() => {
    syncMediaPlayback();
    renderPreview();
  }, [clips, currentTime, isPlaying]);

  useEffect(() => {
    const onMove = (event: PointerEvent) => {
      if (!dragRef.current) {
        return;
      }

      const deltaSeconds = (event.clientX - dragRef.current.startX) / zoom;
      setClips((current) =>
        current.map((clip) => {
          if (clip.id !== dragRef.current?.clipId) {
            return clip;
          }

          if (dragRef.current.type === 'move') {
            return { ...clip, startTime: Math.max(0, dragRef.current.startTime + deltaSeconds) };
          }

          if (dragRef.current.type === 'trim-start') {
            const nextTrimStart = Math.min(
              Math.max(0, dragRef.current.startTrim + deltaSeconds),
              clip.trimEnd - MIN_CLIP_DURATION,
            );
            return {
              ...clip,
              trimStart: nextTrimStart,
              startTime: Math.max(0, dragRef.current.startTime + (nextTrimStart - dragRef.current.startTrim)),
            };
          }

          const nextTrimEnd = Math.max(
            clip.trimStart + MIN_CLIP_DURATION,
            Math.min(clip.duration, dragRef.current.startTrim + deltaSeconds),
          );
          return { ...clip, trimEnd: nextTrimEnd };
        }),
      );
    };

    const onUp = () => {
      dragRef.current = null;
    };

    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
  }, [zoom]);

  function ensureToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast((current) => (current === message ? null : current)), 2600);
  }

  function cloneClipState(source: EditorClip[]) {
    return source.map((clip) => ({ ...clip }));
  }

  function pushHistorySnapshot(source: EditorClip[]) {
    if (skipHistoryRef.current) {
      return;
    }

    historyRef.current.push(cloneClipState(source));
    if (historyRef.current.length > 40) {
      historyRef.current.shift();
    }
  }

  function undoLastChange() {
    const previous = historyRef.current.pop();
    if (!previous) {
      ensureToast('No hay acciones para deshacer.');
      return;
    }

    setClips((current) => {
      const currentIds = new Set(current.map((clip) => clip.id));
      const previousIds = new Set(previous.map((clip) => clip.id));
      current
        .filter((clip) => currentIds.has(clip.id) && !previousIds.has(clip.id))
        .forEach((clip) => revokeClipResources([clip]));
      return cloneClipState(previous);
    });

    setSelectedClipId((current) => (previous.some((clip) => clip.id === current) ? current : previous[0]?.id ?? null));
    ensureToast('Accion deshecha.');
  }

  function sanitizeText(value: string) {
    return value.replace(/[<>]/g, '').trim();
  }

  function revokeClipResources(targetClips: EditorClip[]) {
    targetClips.forEach((clip) => {
      mediaNodesRef.current.get(clip.id)?.element.pause();
      mediaNodesRef.current.get(clip.id)?.gain.disconnect();
      mediaNodesRef.current.get(clip.id)?.source.disconnect();
      mediaNodesRef.current.delete(clip.id);
      imageNodesRef.current.delete(clip.id);
      if (clip.url) {
        URL.revokeObjectURL(clip.url);
      }
    });
  }

  async function refreshProjects() {
    try {
      setProjects(await studioStorage.listProjects());
    } catch {
      ensureToast('No fue posible leer los proyectos guardados.');
    }
  }

  function getAudioContext() {
    const context = audioContextRef.current;
    if (!context) {
      throw new Error('AudioContext no disponible.');
    }

    if (context.state === 'suspended') {
      void context.resume();
    }

    return context;
  }

  function getMediaNode(clip: EditorClip) {
    if (!isMediaClip(clip) || !clip.url) {
      return null;
    }

    const existing = mediaNodesRef.current.get(clip.id);
    if (existing) {
      return existing;
    }

    const context = getAudioContext();
    const destination = audioDestinationRef.current;
    if (!destination) {
      return null;
    }

    const element = document.createElement(clip.kind === 'video' ? 'video' : 'audio');
    element.src = clip.url;
    element.preload = 'auto';
    element.crossOrigin = 'anonymous';
    element.muted = true;
    if (clip.kind === 'video') {
      (element as HTMLVideoElement).playsInline = true;
    }

    const source = context.createMediaElementSource(element);
    const gain = context.createGain();
    source.connect(gain);
    gain.connect(context.destination);
    gain.connect(destination);

    const node = { element, source, gain };
    mediaNodesRef.current.set(clip.id, node);
    return node;
  }

  function getImageNode(clip: EditorClip) {
    if (clip.kind !== 'image' || !clip.url) {
      return null;
    }

    const existing = imageNodesRef.current.get(clip.id);
    if (existing) {
      return existing;
    }

    const image = new Image();
    image.src = clip.url;
    imageNodesRef.current.set(clip.id, image);
    return image;
  }

  function syncMediaPlayback() {
    clips.forEach((clip) => {
      const node = getMediaNode(clip);
      if (!node) {
        return;
      }

      const active = currentTime >= clip.startTime && currentTime < clipEnd(clip);
      node.gain.gain.value = active && !clip.muted ? clip.volume : 0;

      if (!active) {
        if (!node.element.paused) {
          node.element.pause();
        }
        return;
      }

      const targetTime = clip.trimStart + (currentTime - clip.startTime);
      if (Math.abs(node.element.currentTime - targetTime) > 0.18) {
        node.element.currentTime = targetTime;
      }

      if (isPlaying) {
        void node.element.play().catch(() => undefined);
      } else if (!node.element.paused) {
        node.element.pause();
      }
    });
  }

  function renderPreview() {
    const canvas = canvasRef.current;
    if (!canvas) {
      return;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      return;
    }

    ctx.fillStyle = '#020617';
    ctx.fillRect(0, 0, PREVIEW_WIDTH, PREVIEW_HEIGHT);
    const previewGradient = ctx.createLinearGradient(0, 0, PREVIEW_WIDTH, PREVIEW_HEIGHT);
    previewGradient.addColorStop(0, 'rgba(56, 189, 248, 0.08)');
    previewGradient.addColorStop(1, 'rgba(34, 197, 94, 0.05)');
    ctx.fillStyle = previewGradient;
    ctx.fillRect(0, 0, PREVIEW_WIDTH, PREVIEW_HEIGHT);

    const visualClips = clips
      .filter((clip) => isVisualClip(clip) && currentTime >= clip.startTime && currentTime < clipEnd(clip))
      .sort((a, b) => getTrackOrder(a.trackId) - getTrackOrder(b.trackId));

    if (visualClips.length === 0) {
      ctx.fillStyle = '#e2e8f0';
      ctx.font = '600 34px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Importa medios o graba para comenzar la edicion', PREVIEW_WIDTH / 2, PREVIEW_HEIGHT / 2 - 10);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '400 20px Inter, sans-serif';
      ctx.fillText('El editor ya admite timeline, trim, mezcla de audio y export WebM.', PREVIEW_WIDTH / 2, PREVIEW_HEIGHT / 2 + 26);
      return;
    }

    visualClips.forEach((clip) => {
      if (clip.kind === 'video') {
        const node = getMediaNode(clip);
        if (node && (node.element as HTMLVideoElement).readyState >= 2) {
          drawCover(ctx, node.element as HTMLVideoElement, PREVIEW_WIDTH, PREVIEW_HEIGHT);
        }
        return;
      }

      if (clip.kind === 'image') {
        const image = getImageNode(clip);
        if (image?.complete) {
          drawContain(ctx, image, PREVIEW_WIDTH, PREVIEW_HEIGHT);
        }
        return;
      }

      if (clip.kind === 'text') {
        ctx.save();
        ctx.fillStyle = clip.background ?? 'rgba(2, 6, 23, 0.55)';
        ctx.fillRect(80, PREVIEW_HEIGHT - 170, PREVIEW_WIDTH - 160, 88);
        ctx.fillStyle = clip.color ?? '#ffffff';
        ctx.font = '600 42px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(clip.text ?? '', PREVIEW_WIDTH / 2, PREVIEW_HEIGHT - 116);
        ctx.restore();
      }
    });

    ctx.save();
    ctx.strokeStyle = 'rgba(226, 232, 240, 0.14)';
    ctx.lineWidth = 2;
    ctx.strokeRect(28, 28, PREVIEW_WIDTH - 56, PREVIEW_HEIGHT - 56);
    ctx.fillStyle = 'rgba(2, 6, 23, 0.74)';
    ctx.fillRect(28, 28, 310, 42);
    ctx.fillStyle = '#e2e8f0';
    ctx.font = '600 18px Inter, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(selectedClip ? `Clip activo: ${selectedClip.name}` : 'Timeline activa', 42, 55);
    ctx.restore();
  }

  function handlePlaybackEnd() {
    setIsPlaying(false);
    if (exportRecorderRef.current) {
      const recorder = exportRecorderRef.current;
      exportRecorderRef.current = null;
      void recorder.stop().then((blob) => {
        setExporting(false);
        if (!blob) {
          return;
        }

        if (exportUrl) {
          URL.revokeObjectURL(exportUrl);
        }

        const url = URL.createObjectURL(blob);
        setExportUrl(url);
        const link = document.createElement('a');
        link.href = url;
        link.download = `studio-recorder-edit-${new Date().toISOString().replace(/[:.]/g, '-')}.webm`;
        link.click();
        ensureToast('Exportacion WebM lista. Descarga iniciada.');
      });
    }
  }

  function pauseAllMedia() {
    mediaNodesRef.current.forEach((node) => {
      node.element.pause();
    });
  }

  function togglePlayback() {
    if (totalDuration === 0) {
      ensureToast('Importa o graba primero un clip para reproducir.');
      return;
    }

    if (currentTime >= totalDuration) {
      setCurrentTime(0);
    }

    setIsPlaying((value) => !value);
  }

  async function createClipFromBlob(blob: Blob, name: string, kind: 'video' | 'audio' | 'image', insertAtStart = false) {
    const url = URL.createObjectURL(blob);

    if (kind === 'image') {
      const imageTrackId = 'video-2';
      return {
        id: createClipId(),
        name,
        kind,
        trackId: imageTrackId,
        startTime: insertAtStart ? 0 : getTrackEnd(clips, imageTrackId),
        trimStart: 0,
        trimEnd: 5,
        duration: 5,
        volume: 1,
        muted: false,
        blob,
        url,
      } satisfies EditorClip;
    }

    const element = document.createElement(kind === 'video' ? 'video' : 'audio');
    element.preload = 'metadata';
    element.src = url;

    const duration = await new Promise<number>((resolve, reject) => {
      element.onloadedmetadata = () => resolve(Number.isFinite(element.duration) ? element.duration : 5);
      element.onerror = () => reject(new Error('No fue posible leer la metadata del archivo.'));
    });

    const trackId = getDefaultTrackId(kind);
    return {
      id: createClipId(),
      name,
      kind,
      trackId,
      startTime: insertAtStart ? 0 : getTrackEnd(clips, trackId),
      trimStart: 0,
      trimEnd: duration,
      duration,
      volume: 1,
      muted: false,
      blob,
      url,
    } satisfies EditorClip;
  }

  async function importBlobAsClip(blob: Blob, name: string, kind: 'video' | 'audio' | 'image', insertAtStart = false) {
    try {
      const clip = await createClipFromBlob(blob, name, kind, insertAtStart);
      setClips((current) => {
        pushHistorySnapshot(current);
        return [...current, clip].sort(sortClips);
      });
      setSelectedClipId(clip.id);
      ensureToast(`Clip agregado a ${getTrackDefinition(clip.trackId).label}.`);
    } catch {
      ensureToast('No fue posible importar ese archivo.');
    }
  }

  async function handleImportFiles(event: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(event.target.files ?? []);
    for (const file of files) {
      if (file.type.startsWith('video/')) {
        await importBlobAsClip(file, file.name, 'video');
      } else if (file.type.startsWith('audio/')) {
        await importBlobAsClip(file, file.name, 'audio');
      } else if (file.type.startsWith('image/')) {
        await importBlobAsClip(file, file.name, 'image');
      }
    }

    event.target.value = '';
  }

  function addTextClip() {
    const trackId: EditorTrackId = 'overlay-1';
    const cleanText = sanitizeText(textDraft) || 'Nuevo texto';
    const clip: EditorClip = {
      id: createClipId(),
      name: cleanText.slice(0, 20) || 'Texto',
      kind: 'text',
      trackId,
      startTime: getTrackEnd(clips, trackId),
      trimStart: 0,
      trimEnd: 4,
      duration: 4,
      volume: 1,
      muted: false,
      text: cleanText,
      color: '#ffffff',
      background: 'rgba(2, 6, 23, 0.55)',
    };

    setClips((current) => {
      pushHistorySnapshot(current);
      return [...current, clip].sort(sortClips);
    });
    setSelectedClipId(clip.id);
    ensureToast('Overlay de texto agregado.');
  }

  function updateClip(clipId: string, patch: Partial<EditorClip>) {
    setClips((current) => {
      pushHistorySnapshot(current);
      return current.map((clip) => (clip.id === clipId ? { ...clip, ...patch } : clip)).sort(sortClips);
    });
  }

  function deleteClip(clipId: string) {
    setClips((current) => {
      pushHistorySnapshot(current);
      const target = current.find((clip) => clip.id === clipId);
      if (target) {
        revokeClipResources([target]);
      }
      return current.filter((clip) => clip.id !== clipId);
    });
    setSelectedClipId((current) => (current === clipId ? null : current));
  }

  function splitClip(clipId: string) {
    setClips((current) => {
      const source = current.find((clip) => clip.id === clipId);
      if (!source) {
        return current;
      }

      if (currentTime <= source.startTime + MIN_CLIP_DURATION || currentTime >= clipEnd(source) - MIN_CLIP_DURATION) {
        ensureToast('Mueve el cabezal dentro del clip para poder cortarlo.');
        return current;
      }

      const offset = currentTime - source.startTime;
      const splitTrim = source.trimStart + offset;
      pushHistorySnapshot(current);
      const left: EditorClip = { ...source, trimEnd: splitTrim };
      const right: EditorClip = {
        ...source,
        id: createClipId(),
        name: `${source.name} B`,
        startTime: currentTime,
        trimStart: splitTrim,
      };

      setSelectedClipId(right.id);
      ensureToast('Clip dividido en el cabezal actual.');
      return current.flatMap((clip) => (clip.id === clipId ? [left, right] : clip)).sort(sortClips);
    });
  }

  function nudgeClip(clipId: string, amount: number) {
    const target = clips.find((clip) => clip.id === clipId);
    if (!target) {
      return;
    }

    updateClip(clipId, { startTime: Math.max(0, target.startTime + amount) });
  }

  function duplicateClip(clipId: string) {
    setClips((current) => {
      pushHistorySnapshot(current);
      const source = current.find((clip) => clip.id === clipId);
      if (!source) {
        return current;
      }

      const clone: EditorClip = {
        ...source,
        id: createClipId(),
        startTime: clipEnd(source) + 0.2,
        name: `${source.name} copia`,
      };

      setSelectedClipId(clone.id);
      return [...current, clone].sort(sortClips);
    });
  }

  function seekTo(time: number) {
    pauseAllMedia();
    setIsPlaying(false);
    setCurrentTime(Math.max(0, Math.min(totalDuration || 0, time)));
  }

  async function saveProject() {
    if (clips.length === 0) {
      ensureToast('No hay clips para guardar como proyecto.');
      return;
    }

    const name = window.prompt('Nombre del proyecto', `Proyecto ${new Date().toLocaleString()}`)?.trim();
    if (!name) {
      return;
    }

    const projectId = `project-${Date.now()}`;
    const now = new Date().toISOString();
    const record: ProjectRecord = {
      id: projectId,
      name,
      createdAt: now,
      updatedAt: now,
      duration: totalDuration,
      clips: clips.map((clip) => ({
        ...clip,
        url: undefined,
        blob: undefined,
        text: clip.text ? sanitizeText(clip.text) : clip.text,
      })),
    };

    try {
      setSavingProject(true);
      await studioStorage.saveProject(
        record,
        clips
          .filter((clip) => clip.blob)
          .map((clip) => ({
            projectId,
            clipId: clip.id,
            blob: clip.blob as Blob,
            name: clip.name,
          })),
      );
      await refreshProjects();
      ensureToast('Proyecto guardado localmente.');
    } catch {
      ensureToast('No fue posible guardar el proyecto localmente.');
    } finally {
      setSavingProject(false);
    }
  }

  async function loadProject(projectId: string) {
    try {
      const snapshot = await studioStorage.getProject(projectId);
      if (!snapshot) {
        ensureToast('El proyecto solicitado no existe.');
        return;
      }

      pauseAllMedia();
      setIsPlaying(false);
      setCurrentTime(0);

      setClips((current) => {
        pushHistorySnapshot(current);
        revokeClipResources(current);
        return [];
      });

      const assetsByClipId = new Map(snapshot.assets.map((asset) => [asset.clipId, asset]));
      skipHistoryRef.current = true;
      const nextClips: EditorClip[] = snapshot.project.clips.map((clip) => {
        const asset = assetsByClipId.get(clip.id);
        const blob = asset?.blob;
        return {
          ...clip,
          blob,
          url: blob ? URL.createObjectURL(blob) : undefined,
        };
      });

      setClips(nextClips);
      setSelectedClipId(nextClips[0]?.id ?? null);
      historyRef.current = [];
      skipHistoryRef.current = false;
      ensureToast(`Proyecto "${snapshot.project.name}" cargado.`);
    } catch {
      skipHistoryRef.current = false;
      ensureToast('No fue posible cargar el proyecto.');
    }
  }

  async function deleteProject(projectId: string) {
    try {
      await studioStorage.deleteProject(projectId);
      await refreshProjects();
      ensureToast('Proyecto eliminado del almacenamiento local.');
    } catch {
      ensureToast('No fue posible eliminar el proyecto.');
    }
  }

  function exportWebm() {
    const canvas = canvasRef.current;
    const destination = audioDestinationRef.current;
    if (!canvas) {
      return;
    }

    if (totalDuration === 0) {
      ensureToast('No hay contenido en la timeline para exportar.');
      return;
    }

    const recorder = new RecorderPipeline();
    exportRecorderRef.current = recorder;
    recorder.start(canvas.captureStream(30), destination?.stream.getAudioTracks()[0] ?? null);
    setCurrentTime(0);
    setExporting(true);
    setIsPlaying(true);
    ensureToast('Exportando WebM desde la timeline actual...');
  }

  const timelineWidth = Math.max(totalDuration * zoom + 200, 1200);
  const playheadPercent = totalDuration > 0 ? Math.min(100, (currentTime / totalDuration) * 100) : 0;

  return (
    <div className="space-y-5">
      <div className="glass rounded-[30px] border px-5 py-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-sky-300">Editor NLE</p>
            <h2 className="mt-2 text-2xl font-semibold text-white">Editor multipista integrado</h2>
            <p className="mt-2 max-w-3xl text-sm text-slate-400">
              La grabacion entra directo al editor. Ya puedes sumar pistas, reordenar secuencias, recortar, duplicar,
              mezclar audio e incorporar imagenes o textos sin salir del flujo.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button type="button" className="btn-secondary" onClick={onBackToStudio}>
              Volver al studio
            </button>
            <button type="button" className="rounded-full border border-white/10 px-4 py-3 text-sm font-semibold text-slate-200 disabled:opacity-50" onClick={() => void saveProject()} disabled={savingProject}>
              {savingProject ? 'Guardando...' : 'Guardar proyecto'}
            </button>
            <button type="button" className="rounded-full border border-white/10 px-4 py-3 text-sm font-semibold text-slate-200" onClick={undoLastChange}>
              Deshacer
            </button>
            <button type="button" className="rounded-full border border-white/10 px-4 py-3 text-sm font-semibold text-slate-200 disabled:opacity-40" onClick={() => selectedClip && splitClip(selectedClip.id)} disabled={!selectedClip}>
              Cortar clip
            </button>
            <button type="button" className="rounded-full border border-white/10 px-4 py-3 text-sm font-semibold text-slate-200" onClick={togglePlayback}>
              {isPlaying ? 'Pausar' : 'Reproducir'}
            </button>
            <button type="button" className="btn-primary" onClick={exportWebm} disabled={exporting}>
              {exporting ? 'Exportando...' : 'Exportar WebM'}
            </button>
          </div>
        </div>
      </div>

      {selectedClip ? (
        <section className="glass rounded-[24px] border px-4 py-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-sky-300">Barra Contextual</p>
              <h3 className="mt-1 text-lg font-semibold text-white">{selectedClip.name}</h3>
            </div>
            <div className="flex flex-wrap gap-2 text-sm">
              <button type="button" className="rounded-full border border-white/10 px-3 py-2 text-slate-200" onClick={() => seekTo(selectedClip.startTime)}>
                Ir al clip
              </button>
              <button type="button" className="rounded-full border border-white/10 px-3 py-2 text-slate-200" onClick={() => splitClip(selectedClip.id)}>
                Cortar [C]
              </button>
              <button type="button" className="rounded-full border border-white/10 px-3 py-2 text-slate-200" onClick={() => duplicateClip(selectedClip.id)}>
                Duplicar
              </button>
              <button type="button" className="rounded-full border border-white/10 px-3 py-2 text-slate-200" onClick={() => nudgeClip(selectedClip.id, -0.25)}>
                -0.25s
              </button>
              <button type="button" className="rounded-full border border-white/10 px-3 py-2 text-slate-200" onClick={() => nudgeClip(selectedClip.id, 0.25)}>
                +0.25s
              </button>
              <button type="button" className="rounded-full border border-orange-300/20 px-3 py-2 text-orange-200" onClick={() => deleteClip(selectedClip.id)}>
                Eliminar
              </button>
            </div>
          </div>
        </section>
      ) : null}

      <div className="grid gap-5 xl:grid-cols-[1.15fr_0.85fr]">
        <section className="glass rounded-[30px] border p-5">
          <div className="mb-4 grid gap-3 lg:grid-cols-[1fr_auto] lg:items-center">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-sky-300">Previsualizador</p>
              <h3 className="mt-2 text-xl font-semibold text-white">Salida actual del montaje</h3>
              <p className="mt-2 text-sm text-slate-400">El preview sigue el playhead y refleja el corte activo, los overlays y el audio mezclado.</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button type="button" className="rounded-full border border-white/10 px-4 py-2 text-sm text-slate-200" onClick={() => seekTo(0)}>
                Al inicio
              </button>
              <button type="button" className="rounded-full border border-white/10 px-4 py-2 text-sm text-slate-200 disabled:opacity-40" onClick={() => selectedClip && nudgeClip(selectedClip.id, -0.25)} disabled={!selectedClip}>
                Mover -0.25s
              </button>
              <button type="button" className="rounded-full border border-white/10 px-4 py-2 text-sm text-slate-200 disabled:opacity-40" onClick={() => selectedClip && nudgeClip(selectedClip.id, 0.25)} disabled={!selectedClip}>
                Mover +0.25s
              </button>
            </div>
          </div>
          <div className="overflow-hidden rounded-[28px] border border-white/8 bg-black p-3">
            <canvas ref={canvasRef} className="aspect-video w-full rounded-[24px] bg-slate-950" />
          </div>

          <div className="mt-4 rounded-2xl border border-white/8 bg-slate-950/35 p-4">
            <div className="mb-3 flex items-center justify-between gap-3 text-sm text-slate-300">
              <span>{selectedClip ? `Clip activo: ${selectedClip.name}` : 'Ningun clip seleccionado'}</span>
              <span>{formatSeconds(currentTime)} / {formatSeconds(totalDuration)}</span>
            </div>
            <button
              type="button"
              className="relative h-3 w-full overflow-hidden rounded-full bg-white/8"
              onClick={(event) => {
                const rect = event.currentTarget.getBoundingClientRect();
                const ratio = (event.clientX - rect.left) / rect.width;
                seekTo(totalDuration * Math.max(0, Math.min(1, ratio)));
              }}
            >
              <span className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-emerald-400 to-sky-400" style={{ width: `${playheadPercent}%` }} />
            </button>
          </div>

          <div className="mt-4 grid gap-4 md:grid-cols-[1fr_auto] md:items-center">
            <div className="flex flex-wrap items-center gap-2 text-sm text-slate-300">
              <span className="rounded-full border border-white/10 bg-slate-950/45 px-4 py-2">{formatSeconds(currentTime)}</span>
              <span className="text-slate-500">/</span>
              <span className="rounded-full border border-white/10 bg-slate-950/45 px-4 py-2">{formatSeconds(totalDuration)}</span>
              {exportUrl ? (
                <a href={exportUrl} download className="rounded-full border border-emerald-300/30 bg-emerald-400/10 px-4 py-2 text-emerald-200">
                  Descargar ultimo export
                </a>
              ) : null}
            </div>

            <div className="flex items-center gap-3 text-sm text-slate-300">
              <label htmlFor="editor-zoom">Zoom timeline</label>
              <input
                id="editor-zoom"
                type="range"
                min="40"
                max="180"
                value={zoom}
                onChange={(event) => setZoom(Number(event.target.value))}
                className="accent-sky-400"
              />
            </div>
          </div>

          <div className="mt-5 flex flex-wrap gap-3">
            <button type="button" className="btn-primary" onClick={() => fileInputRef.current?.click()}>
              Importar video, audio o imagen
            </button>
            <input ref={fileInputRef} type="file" accept="video/*,audio/*,image/*" multiple className="hidden" onChange={handleImportFiles} />

            <div className="flex flex-wrap items-center gap-2 rounded-full border border-white/10 bg-slate-950/35 px-3 py-2">
              <input
                type="text"
                value={textDraft}
                onChange={(event) => setTextDraft(event.target.value)}
                className="w-48 bg-transparent text-sm text-white outline-none"
                placeholder="Texto overlay"
              />
              <button type="button" className="rounded-full bg-white/8 px-3 py-2 text-sm text-slate-200" onClick={addTextClip}>
                Agregar texto
              </button>
            </div>
          </div>
        </section>

        <aside className="glass rounded-[30px] border p-5">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-emerald-300">Acciones + Inspector</p>
              <h3 className="mt-2 text-xl font-semibold text-white">Clip seleccionado</h3>
            </div>
            {selectedClip ? (
              <div className="flex gap-2">
                <button type="button" className="rounded-full border border-white/10 px-3 py-2 text-xs text-slate-200" onClick={() => duplicateClip(selectedClip.id)}>
                  Duplicar
                </button>
                <button type="button" className="rounded-full border border-orange-300/20 px-3 py-2 text-xs text-orange-200" onClick={() => deleteClip(selectedClip.id)}>
                  Eliminar
                </button>
              </div>
            ) : null}
          </div>

          {selectedClip ? (
            <div className="mt-5 space-y-4 text-sm text-slate-300">
              <div className="rounded-2xl border border-white/8 bg-slate-950/35 p-4">
                <strong className="block text-base text-white">{selectedClip.name}</strong>
                <p className="mt-1 text-slate-400">{getTrackDefinition(selectedClip.trackId).label} · {selectedClip.kind}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <button type="button" className="rounded-full border border-white/10 px-3 py-2 text-xs text-slate-200" onClick={() => splitClip(selectedClip.id)}>
                    Cortar
                  </button>
                  <button type="button" className="rounded-full border border-white/10 px-3 py-2 text-xs text-slate-200" onClick={() => nudgeClip(selectedClip.id, -0.25)}>
                    -0.25s
                  </button>
                  <button type="button" className="rounded-full border border-white/10 px-3 py-2 text-xs text-slate-200" onClick={() => nudgeClip(selectedClip.id, 0.25)}>
                    +0.25s
                  </button>
                </div>
              </div>

              <label className="block">
                <span className="mb-2 block">Pista</span>
                <select
                  value={selectedClip.trackId}
                  onChange={(event) => updateClip(selectedClip.id, { trackId: event.target.value as EditorTrackId })}
                  className="w-full rounded-2xl border border-white/10 bg-slate-950/70 px-3 py-3 text-white"
                >
                  {EDITOR_TRACKS.filter((track) => {
                    if (selectedClip.kind === 'audio') return track.kind === 'audio';
                    if (selectedClip.kind === 'text') return track.kind === 'overlay';
                    return track.kind === 'video';
                  }).map((track) => (
                    <option key={track.id} value={track.id}>{track.label}</option>
                  ))}
                </select>
              </label>

              <label className="block">
                <div className="mb-2 flex items-center justify-between">
                  <span>Inicio en timeline</span>
                  <span>{selectedClip.startTime.toFixed(2)}s</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max={Math.max(totalDuration + 5, selectedClip.startTime + 5)}
                  step="0.1"
                  value={selectedClip.startTime}
                  onChange={(event) => updateClip(selectedClip.id, { startTime: Number(event.target.value) })}
                  className="w-full accent-sky-400"
                />
              </label>

              <label className="block">
                <div className="mb-2 flex items-center justify-between">
                  <span>Trim inicio</span>
                  <span>{selectedClip.trimStart.toFixed(2)}s</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max={Math.max(0, selectedClip.trimEnd - MIN_CLIP_DURATION)}
                  step="0.05"
                  value={selectedClip.trimStart}
                  onChange={(event) => updateClip(selectedClip.id, { trimStart: Number(event.target.value) })}
                  className="w-full accent-emerald-400"
                />
              </label>

              <label className="block">
                <div className="mb-2 flex items-center justify-between">
                  <span>Trim fin</span>
                  <span>{selectedClip.trimEnd.toFixed(2)}s</span>
                </div>
                <input
                  type="range"
                  min={selectedClip.trimStart + MIN_CLIP_DURATION}
                  max={selectedClip.duration}
                  step="0.05"
                  value={selectedClip.trimEnd}
                  onChange={(event) => updateClip(selectedClip.id, { trimEnd: Number(event.target.value) })}
                  className="w-full accent-emerald-400"
                />
              </label>

              {selectedClip.kind === 'audio' || selectedClip.kind === 'video' ? (
                <label className="block">
                  <div className="mb-2 flex items-center justify-between">
                    <span>Volumen</span>
                    <span>{Math.round(selectedClip.volume * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="2"
                    step="0.05"
                    value={selectedClip.volume}
                    onChange={(event) => updateClip(selectedClip.id, { volume: Number(event.target.value) })}
                    className="w-full accent-orange-400"
                  />
                </label>
              ) : null}

              <label className="flex items-center justify-between rounded-2xl border border-white/8 bg-slate-950/35 px-3 py-3">
                <span>Mute</span>
                <input
                  type="checkbox"
                  checked={selectedClip.muted}
                  onChange={(event) => updateClip(selectedClip.id, { muted: event.target.checked })}
                  className="h-4 w-4 accent-emerald-400"
                />
              </label>

              {selectedClip.kind === 'text' ? (
                <>
                  <label className="block">
                    <span className="mb-2 block">Texto</span>
                    <textarea
                      value={selectedClip.text ?? ''}
                      onChange={(event) => updateClip(selectedClip.id, { text: event.target.value, name: event.target.value.slice(0, 20) || 'Texto' })}
                      className="h-28 w-full rounded-2xl border border-white/10 bg-slate-950/70 px-3 py-3 text-white"
                    />
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <label className="block">
                      <span className="mb-2 block">Texto</span>
                      <input type="color" value={selectedClip.color ?? '#ffffff'} onChange={(event) => updateClip(selectedClip.id, { color: event.target.value })} className="h-12 w-full rounded-2xl border border-white/10 bg-slate-950/70 p-2" />
                    </label>
                    <label className="block">
                      <span className="mb-2 block">Fondo</span>
                      <input type="color" value={(selectedClip.background ?? '#020617').slice(0, 7)} onChange={(event) => updateClip(selectedClip.id, { background: `${event.target.value}cc` })} className="h-12 w-full rounded-2xl border border-white/10 bg-slate-950/70 p-2" />
                    </label>
                  </div>
                </>
              ) : null}
            </div>
          ) : (
            <div className="mt-5 rounded-2xl border border-dashed border-white/12 bg-slate-950/20 px-4 py-10 text-sm text-slate-400">
              Selecciona un clip en la timeline para editar su pista, trim, volumen, mute o texto.
            </div>
          )}
        </aside>
      </div>

      <section className="glass rounded-[30px] border p-5">
        <div className="mb-4 flex items-center justify-between gap-3">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-emerald-300">Proyectos locales</p>
            <h3 className="mt-2 text-xl font-semibold text-white">Biblioteca de sesiones</h3>
          </div>
          <span className="rounded-full border border-white/10 bg-slate-950/35 px-4 py-2 text-sm text-slate-300">
            {projects.length} guardados
          </span>
        </div>

        {projects.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-white/12 bg-slate-950/20 px-4 py-8 text-sm text-slate-400">
            Aun no tienes proyectos guardados en este navegador.
          </div>
        ) : (
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {projects.map((project) => (
              <article key={project.id} className="rounded-2xl border border-white/8 bg-slate-950/35 p-4 text-sm text-slate-300">
                <strong className="block text-white">{project.name}</strong>
                <p className="mt-2 text-slate-400">Actualizado: {new Date(project.updatedAt).toLocaleString()}</p>
                <p className="mt-1 text-slate-400">Duracion: {formatSeconds(project.duration)}</p>
                <p className="mt-1 text-slate-400">Clips: {project.clips.length}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <button type="button" className="rounded-full border border-emerald-300/20 bg-emerald-400/10 px-3 py-2 text-xs text-emerald-100" onClick={() => void loadProject(project.id)}>
                    Cargar
                  </button>
                  <button type="button" className="rounded-full border border-orange-300/20 px-3 py-2 text-xs text-orange-200" onClick={() => void deleteProject(project.id)}>
                    Eliminar
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      <section className="glass overflow-hidden rounded-[30px] border p-5">
        <div className="mb-4 flex items-center justify-between gap-3">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-sky-300">Timeline</p>
            <h3 className="mt-2 text-xl font-semibold text-white">Multipista inicial</h3>
          </div>
          <button type="button" className="rounded-full border border-white/10 px-4 py-2 text-sm text-slate-200" onClick={() => seekTo(0)}>
            Ir al inicio
          </button>
        </div>

        <div className="overflow-x-auto pb-2">
          <div className="relative min-h-[480px]" style={{ width: timelineWidth }}>
            <div className="mb-3 flex gap-0 text-xs text-slate-500">
              {Array.from({ length: Math.ceil(totalDuration) + 8 }, (_, second) => (
                <div key={second} className="relative shrink-0 border-l border-white/8 pl-2" style={{ width: zoom }}>
                  {second}s
                </div>
              ))}
            </div>

            <div className="absolute top-0 z-20 h-full w-px bg-rose-400" style={{ left: currentTime * zoom }} />

            <div className="space-y-3">
              {EDITOR_TRACKS.map((track) => {
                const laneClips = clips
                  .filter((clip) => clip.trackId === track.id)
                  .sort((a, b) => a.startTime - b.startTime);

                return (
                  <div key={track.id} className="grid grid-cols-[120px_1fr] items-stretch gap-3">
                    <div className="rounded-2xl border border-white/8 bg-slate-950/35 px-4 py-4 text-sm text-slate-200">
                      <strong className="block text-white">{track.label}</strong>
                      <span className="mt-1 block text-slate-500">{track.kind}</span>
                    </div>

                    <div className="relative h-20 rounded-2xl border border-white/8 bg-slate-950/30" onDoubleClick={(event) => {
                      const rect = (event.currentTarget as HTMLDivElement).getBoundingClientRect();
                      seekTo((event.clientX - rect.left) / zoom);
                    }}>
                      {laneClips.map((clip) => {
                        const left = clip.startTime * zoom;
                        const width = Math.max(clipDuration(clip) * zoom, 28);
                        const isSelected = selectedClipId === clip.id;

                        return (
                          <div
                            key={clip.id}
                            className={[
                              'absolute top-2 h-16 rounded-2xl border px-3 py-2 shadow-lg transition',
                              isSelected
                                ? 'border-emerald-300/70 bg-emerald-400/18 text-white'
                                : 'border-white/10 bg-sky-400/12 text-slate-100 hover:border-white/20',
                            ].join(' ')}
                            style={{ left, width }}
                            onPointerDown={(event) => {
                              pushHistorySnapshot(clips);
                              dragRef.current = { type: 'move', clipId: clip.id, startX: event.clientX, startTime: clip.startTime };
                              setSelectedClipId(clip.id);
                            }}
                            onClick={() => setSelectedClipId(clip.id)}
                          >
                            <button
                              type="button"
                              className="absolute left-0 top-0 h-full w-3 cursor-ew-resize rounded-l-2xl bg-black/20"
                              onPointerDown={(event) => {
                                event.stopPropagation();
                                pushHistorySnapshot(clips);
                                dragRef.current = {
                                  type: 'trim-start',
                                  clipId: clip.id,
                                  startX: event.clientX,
                                  startTrim: clip.trimStart,
                                  startTime: clip.startTime,
                                };
                              }}
                            />
                            <button
                              type="button"
                              className="absolute right-0 top-0 h-full w-3 cursor-ew-resize rounded-r-2xl bg-black/20"
                              onPointerDown={(event) => {
                                event.stopPropagation();
                                pushHistorySnapshot(clips);
                                dragRef.current = {
                                  type: 'trim-end',
                                  clipId: clip.id,
                                  startX: event.clientX,
                                  startTrim: clip.trimEnd,
                                };
                              }}
                            />
                            <span className="block truncate text-sm font-semibold">{clip.name}</span>
                            <span className="mt-1 block text-[11px] text-slate-200/80">
                              {clip.kind} · {clipDuration(clip).toFixed(1)}s
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {toast ? (
        <div className="fixed bottom-5 right-5 z-50 rounded-2xl border border-emerald-300/20 bg-emerald-400/14 px-4 py-3 text-sm text-emerald-50 shadow-xl backdrop-blur">
          {toast}
        </div>
      ) : null}
    </div>
  );
}
