---
trigger: always_on
---

# Guardrails

- No agregar backend ni endpoints.
- No guardar datos personales innecesarios.
- Evitar sobreingeniería: primero Sprint 1 completo y usable.
- Todo cambio debe venir con criterio de aceptación verificable.
- Si una API no está disponible, la UI debe degradar sin romper el flujo.