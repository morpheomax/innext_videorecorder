---
trigger: always_on
---

# Reglas UX

- Máximo 3 pasos para grabar: elegir pantalla → activar cámara/mic → grabar.
- Preview = resultado final.
- Panel lateral de configuración: colapsable + hotkey.
- Mensajes claros para permisos denegados y audio sistema no disponible.