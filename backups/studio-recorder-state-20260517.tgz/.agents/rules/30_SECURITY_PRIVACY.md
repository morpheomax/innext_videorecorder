---
trigger: always_on
---

# Privacidad y seguridad

- Procesamiento local.
- No enviar grabaciones a terceros.
- Sanitizar overlays de texto (texto plano).
- Botón de borrado local total (cuando exista biblioteca).
- Headers recomendados (CSP) en deploy estático.