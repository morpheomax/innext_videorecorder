---
trigger: always_on
---

# Decisiones de Arquitectura

- Composición por Canvas 2D + canvas.captureStream()
- Mezcla de audio por Web Audio API (Gain por fuente)
- Grabación por MediaRecorder con fallback de mimeType
- Persistencia local: IndexedDB (Sprint 2)
- Export MP4: opcional y explícito (ffmpeg.wasm) (Sprint 3)