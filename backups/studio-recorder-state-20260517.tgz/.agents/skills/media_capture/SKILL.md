# SKILL: Media Capture (Pantalla + Cámara + Mic)

## Objetivo
Obtener MediaStreams confiables para pantalla, cámara y mic con manejo de permisos y fallbacks.

## Inputs
- preferDisplayAudio: boolean
- cameraDeviceId?: string
- micDeviceId?: string

## Outputs
- displayStream: MediaStream
- cameraStream: MediaStream
- micStream: MediaStream
- flags: { hasSystemAudio: boolean }

## Pasos
1) getDisplayMedia({ video: true, audio: preferDisplayAudio })
2) getUserMedia({ video: {deviceId}, audio: false }) para cámara
3) getUserMedia({ audio: {deviceId} }) para mic
4) Detectar system audio: displayStream.getAudioTracks().length > 0
5) Manejar errores: NotAllowedError, NotFoundError

## Snippet (TS)
```ts
export async function captureDisplay(preferAudio: boolean) {
  const stream = await navigator.mediaDevices.getDisplayMedia({
    video: true,
    audio: preferAudio,
  });
  return { stream, hasSystemAudio: stream.getAudioTracks().length > 0 };
}

## B) .agents/skills/audio_mixer/SKILL.md
```md
# SKILL: Audio Mixer (Web Audio API)

## Objetivo
Mezclar mic + system/tab (si existe) en un solo track, con control de ganancia por fuente.

## Inputs
- micStream: MediaStream
- systemStream?: MediaStream
- gains: { mic: number; system: number }

## Outputs
- mixedAudioTrack: MediaStreamTrack
- meters (opcional): niveles RMS

## Pasos
1) Crear AudioContext
2) Crear MediaStreamSource para cada fuente existente
3) Conectar cada source a su GainNode
4) Conectar gains a MediaStreamDestination
5) Obtener destination.stream.getAudioTracks()[0]

## Snippet (TS)
```ts
export function createAudioMix(mic: MediaStream, system?: MediaStream) {
  const ctx = new AudioContext();
  const dest = ctx.createMediaStreamDestination();

  const micSrc = ctx.createMediaStreamSource(mic);
  const micGain = ctx.createGain();
  micGain.gain.value = 1.0;
  micSrc.connect(micGain).connect(dest);

  let sysGain: GainNode | null = null;
  if (system && system.getAudioTracks().length) {
    const sysSrc = ctx.createMediaStreamSource(system);
    sysGain = ctx.createGain();
    sysGain.gain.value = 1.0;
    sysSrc.connect(sysGain).connect(dest);
  }

  const track = dest.stream.getAudioTracks()[0];
  return { ctx, dest, micGain, sysGain, track };
}

## C) .agents/skills/canvas_compositor/SKILL.md
```md
# SKILL: Canvas Compositor (Pantalla + Cámara estilo streaming)

## Objetivo
Renderizar pantalla como base y cámara como overlay con máscara y posición libre, generando un stream final.

## Inputs
- displayVideoEl: HTMLVideoElement
- cameraVideoEl: HTMLVideoElement
- preset: "16:9" | "9:16" | "1:1"
- cameraOverlay: { x,y,w,h, shape: "circle"|"square"|"rounded" }

## Outputs
- canvas: HTMLCanvasElement
- canvasStream: MediaStream (video)

## Pasos
1) Crear canvas con dimensiones según preset
2) Loop render (requestAnimationFrame)
3) Dibujar display escalado al canvas
4) Dibujar cámara con máscara:
   - circle: clip con arc()
   - square: rect()
   - rounded: path con roundRect (o manual)
5) canvas.captureStream(fps)

## Snippet máscara circular (TS)
```ts
function drawCircleClip(ctx: CanvasRenderingContext2D, x:number,y:number,w:number,h:number) {
  ctx.save();
  const r = Math.min(w,h)/2;
  ctx.beginPath();
  ctx.arc(x + w/2, y + h/2, r, 0, Math.PI*2);
  ctx.clip();
}

## D) .agents/skills/recorder_pipeline/SKILL.md
```md
# SKILL: Recorder Pipeline (MediaRecorder con fallback)

## Objetivo
Combinar video del canvas + audio mezclado y grabar a chunks descargables.

## Inputs
- videoStream: MediaStream (1 video track)
- audioTrack?: MediaStreamTrack
- preferredMimes: string[]

## Outputs
- start(), pause(), resume(), stop() => Blob

## Pasos
1) Crear MediaStream final y agregar tracks
2) Elegir mimeType soportado con MediaRecorder.isTypeSupported
3) Crear MediaRecorder, recolectar dataavailable
4) stop => new Blob(chunks, {type})

## Snippet (TS)
```ts
export function pickMime(mimes: string[]) {
  for (const m of mimes) if (MediaRecorder.isTypeSupported(m)) return m;
  return "";
}

## E) .agents/skills/local_library_indexeddb/SKILL.md
```md
# SKILL: Biblioteca local (IndexedDB)

## Objetivo
Persistir grabaciones y metadata localmente y listarlas.

## Entidades
- Recording { id, name, created_at, duration_ms, format, mime, size_bytes, blob }
- Settings { ... }

## Inputs/Outputs
- saveRecording(blob, meta) => id
- listRecordings() => RecordingMeta[]
- getRecording(id) => blob+meta
- deleteRecording(id)

## Recomendación
Usar wrapper simple tipo `idb` (o implementación propia) y almacenar blobs en objectStore.

## Criterios de aceptación
- Guardar y listar funciona offline.
- Eliminar libera espacio (según browser).