# SKILL: Editor simple (Trim + Overlays)

## Objetivo
Edición mínima para personalizar: recorte inicio/fin y superposición de texto/logo.

## Alcance MVP editor
- Trim in/out (no destructivo: guardar rangos)
- Overlays: texto y logo (posición + opacidad)

## Implementación sugerida
- Guardar un Project (edición) en IndexedDB
- En export:
  - WebM: re-render canvas + cortar por tiempo (si es simple) o con ffmpeg.wasm (más preciso)

## Criterios de aceptación
- Usuario puede recortar y exportar un archivo final.