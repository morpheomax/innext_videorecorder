# SKILL: Export WebM / MP4

## Objetivo
Exportar grabación editada:
- WebM rápido (nativo si posible)
- MP4 opcional (ffmpeg.wasm) con advertencia de rendimiento

## Reglas
- Default: WebM
- MP4 solo si:
  a) El navegador soporta nativamente (raro) o
  b) El usuario elige “Exportar MP4 (lento)”

## UX
- Barra de progreso + aviso “puede tardar”
- Si falla, fallback a WebM

## Criterios de aceptación
- Export WebM siempre disponible.
- MP4 no bloquea la app (usar worker si aplica).