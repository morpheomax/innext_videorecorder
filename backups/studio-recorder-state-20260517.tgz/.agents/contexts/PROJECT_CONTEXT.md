# Contexto del Proyecto — Studio Recorder

## Objetivo
Construir una app web gratuita (estática, sin backend) para grabar capacitaciones con formato streaming:
- pantalla + cámara reubicable (formas: círculo/cuadrado/rounded)
- audio mic + audio sistema/tab cuando sea posible
- guardado local
- editor simple en fases

## Alcance actual
MVP (Sprint 1): Set + Compositor + MediaRecorder + descarga WebM.
Sprint 2: Biblioteca local (IndexedDB) + settings.
Sprint 3: Editor simple + export MP4 opcional.

## Stack
Vite + React + TypeScript + Tailwind
APIs: getDisplayMedia, getUserMedia, Web Audio API, Canvas 2D, MediaRecorder, IndexedDB.

## Restricciones
- No servidor, no cuentas.
- Audio de sistema depende de navegador/OS → siempre informar fallback.
- Performance: preferir defaults moderados (ej 1280x720/30fps) y permitir ajustes luego.

## Definición de “Done” MVP
- Grabar pantalla + cámara + mic, cámara movible con máscara y preset 16:9/9:16, descargar WebM.