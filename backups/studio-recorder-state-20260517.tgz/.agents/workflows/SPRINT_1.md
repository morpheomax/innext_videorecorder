---
description: 
---

# Workflow: Sprint 1 (Implementación MVP)

Objetivo:
- Set de grabación funcional + descarga WebM.

Pasos:
1) Scaffolding Vite+React+TS+Tailwind
2) Implementar Capture (pantalla/cámara/mic)
3) Implementar AudioMixer (mic + system si existe)
4) Implementar CanvasCompositor (presets + cámara drag + máscara)
5) Implementar RecorderPipeline (MediaRecorder + fallback mime)
6) UI Set: barra control + panel lateral + mensajes de error
7) QA con matriz (docs/QA_TEST_MATRIX.md)

Definición de Done:
- CA del SRS cumplidos.