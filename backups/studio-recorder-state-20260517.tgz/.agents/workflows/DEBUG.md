---
description: 
---

# Workflow: Debug

Checklist rápido:
- ¿getDisplayMedia entrega audio track?
- ¿MediaRecorder soporta mime elegido?
- ¿Canvas resolution/fps muy alto?
- ¿Audio mezclado llega al stream final?
- ¿Permisos bloqueados por settings del navegador?

Salida:
- Diagnóstico + fix + test manual reproducible