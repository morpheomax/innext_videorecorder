---
description: 
---

# Workflow: Planning

Entradas:
- PRD.md, SRS.md, UX.md, ARCH.md, SECURITY.md

Salida:
- Backlog por sprints + tareas técnicas
- Definición de módulos y contratos (interfaces)
- Lista de riesgos y mitigaciones

Regla:
- No iniciar Sprint 2/3 si Sprint 1 no graba y descarga correctamente.